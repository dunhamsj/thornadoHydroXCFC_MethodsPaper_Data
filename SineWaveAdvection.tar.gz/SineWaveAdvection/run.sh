#!/usr/bin/env bash

for Ma in 2.0e-1 1.0e+3; do
  for nN in 02 03; do
    for nX in 0008 0016 0032 0064 0128 0256 0512 1024; do
      mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_Ma${Ma}_nN${nN}_nX${nX}.inputs > Ma${Ma}_nN${nN}_nX${nX}.out &
    done
  done
done

