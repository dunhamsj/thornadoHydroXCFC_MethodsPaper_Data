#!/usr/bin/env bash

mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN02_nXC0032_Multi_FCF.inputs \
                               > Advection1D_SineWaveX1_nN02_nXC0032_Multi_FCF.out &
mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN02_nXC0032_Multi_FCT.inputs \
                               > Advection1D_SineWaveX1_nN02_nXC0032_Multi_FCT.out &
mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN02_nXC0032_Single.inputs    \
                               > Advection1D_SineWaveX1_nN02_nXC0032_Single.out  &

mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN02_nXC0064_Multi_FCF.inputs \
                               > Advection1D_SineWaveX1_nN02_nXC0064_Multi_FCF.out &
mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN02_nXC0064_Multi_FCT.inputs \
                               > Advection1D_SineWaveX1_nN02_nXC0064_Multi_FCT.out &
mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN02_nXC0064_Single.inputs    \
                               > Advection1D_SineWaveX1_nN02_nXC0064_Single.out  &

mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN03_nXC0032_Multi_FCF.inputs \
                               > Advection1D_SineWaveX1_nN03_nXC0032_Multi_FCF.out &
mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN03_nXC0032_Multi_FCT.inputs \
                               > Advection1D_SineWaveX1_nN03_nXC0032_Multi_FCT.out &
mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN03_nXC0032_Single.inputs    \
                               > Advection1D_SineWaveX1_nN03_nXC0032_Single.out &

mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN03_nXC0064_Multi_FCF.inputs \
                               > Advection1D_SineWaveX1_nN03_nXC0064_Multi_FCF.out &
mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN03_nXC0064_Multi_FCT.inputs \
                               > Advection1D_SineWaveX1_nN03_nXC0064_Multi_FCT.out &
mpiexec -n 1 ./main1d.gnu.MPI.ex Advection1D_SineWaveX1_nN03_nXC0064_Single.inputs    \
                               > Advection1D_SineWaveX1_nN03_nXC0064_Single.out &
