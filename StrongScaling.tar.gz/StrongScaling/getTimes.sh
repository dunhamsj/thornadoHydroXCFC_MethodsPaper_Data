#!/usr/bin/env bash

cat *out | grep "Update Fields" | cut -d " " -f 32-32 > walltimes.dat
